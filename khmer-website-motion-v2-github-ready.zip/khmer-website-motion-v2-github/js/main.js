/* =========================================================
   ១) ម៉ាស៊ីនគិតលេខ
   ========================================================= */
(function () {
  var root = document.getElementById("kc-calc");
  var keys = document.getElementById("kc-keys");
  var elV = document.getElementById("kc-value");
  var elE = document.getElementById("kc-expr");
  if (!root || !keys || !elV || !elE) { return; }

  var ERR = "កំហុស";                 // សារកំហុស (ឧ. ចែកនឹងសូន្យ)
  var KH = "០១២៣៤៥៦៧៨៩";            // លេខខ្មែរ ០ ដល់ ៩

  var cur = "0";        // លេខដែលកំពុងបញ្ចូល (ទុកជាលេខអារ៉ាប់ក្នុងកូដ)
  var prev = null;      // លេខមុន
  var op = null;        // គណិតវិធីដែលបានជ្រើស
  var fresh = false;    // true = លេខបន្ទាប់ត្រូវចាប់ផ្តើមថ្មី
  var err = false;      // true = កំពុងបង្ហាញកំហុស
  var exprText = "";    // ឃ្លាបង្ហាញខាងលើ

  // ប្តូរលេខ 0-9 ទៅជាលេខខ្មែរ ០-៩ សម្រាប់បង្ហាញ
  function toKh(s) {
    return String(s).replace(/[0-9]/g, function (d) { return KH.charAt(d); });
  }

  function sym(o) {
    if (o === "*") { return "×"; }
    if (o === "/") { return "÷"; }
    if (o === "-") { return "−"; }
    return o;
  }

  // កាត់ខ្ទង់ដែលវែងពេក (ឧ. 0.1+0.2)
  function fmt(n) { return String(parseFloat(n.toPrecision(12))); }

  // គណនា (ចែកនឹងសូន្យ ត្រឡប់ null)
  function compute(a, b, o) {
    if (o === "+") { return a + b; }
    if (o === "-") { return a - b; }
    if (o === "*") { return a * b; }
    if (o === "/") { return b === 0 ? null : a / b; }
    return b;
  }

  function show() {
    var previousDisplay = elV.textContent;
    elV.textContent = toKh(cur);
    elE.textContent = toKh(exprText);
    // Set size first; then restart the pop animation so the class is not overwritten.
    elV.className = cur.length > 10 ? "kc-value kc-small" : "kc-value";
    if (previousDisplay !== elV.textContent) {
      elV.classList.remove("kc-pop");
      void elV.offsetWidth;
      elV.classList.add("kc-pop");
    }
  }

  function reset() { cur = "0"; prev = null; op = null; fresh = false; err = false; exprText = ""; }
  function fail() { reset(); cur = ERR; err = true; }

  function digit(d) {
    if (fresh) { cur = d; fresh = false; }
    else {
      if (cur.length > 14) { return; }
      cur = (cur === "0") ? d : cur + d;
    }
  }

  function dot() {
    if (fresh) { cur = "0."; fresh = false; return; }
    if (cur.indexOf(".") === -1) { cur += "."; }
  }

  function operator(o) {
    if (op !== null && !fresh) {
      var r = compute(prev, parseFloat(cur), op);
      if (r === null) { fail(); return; }
      cur = fmt(r);
      prev = parseFloat(cur);
    } else if (op === null) {
      prev = parseFloat(cur);
    }
    op = o;
    fresh = true;
    exprText = fmt(prev) + " " + sym(o);
  }

  function equals() {
    if (op === null) { return; }
    var b = parseFloat(cur);
    var r = compute(prev, b, op);
    if (r === null) { fail(); return; }
    exprText = fmt(prev) + " " + sym(op) + " " + fmt(b) + " =";
    cur = fmt(r);
    prev = null;
    op = null;
    fresh = true;
  }

  function percent() { cur = fmt(parseFloat(cur) / 100); fresh = true; }

  function negate() {
    if (cur === "0") { return; }
    cur = (cur.charAt(0) === "-") ? cur.slice(1) : "-" + cur;
  }

  function back() {
    if (fresh) { return; }
    cur = cur.length > 1 ? cur.slice(0, -1) : "0";
    if (cur === "-") { cur = "0"; }
  }

  function handle(k) {
    if (err) { reset(); }
    if (k === "C") { reset(); }
    else if (k === "B") { back(); }
    else if (k === "%") { percent(); }
    else if (k === "N") { negate(); }
    else if (k === ".") { dot(); }
    else if (k === "=") { equals(); }
    else if (k === "+" || k === "-" || k === "*" || k === "/") { operator(k); }
    else if (k.length === 1 && "0123456789".indexOf(k) !== -1) { digit(k); }
    show();
  }

  keys.addEventListener("click", function (e) {
    var btn = e.target.closest ? e.target.closest("button") : e.target;
    var k = btn && btn.getAttribute("data-k");
    if (k) { handle(k); }
  });

  // ប្រើក្តារចុច (ចុចលើម៉ាស៊ីនគិតលេខមួយដងសិន) - ទទួលទាំងលេខខ្មែរ និងលេខអារ៉ាប់
  root.addEventListener("keydown", function (e) {
    var k = e.key;
    var p = KH.indexOf(k);
    if (k.length === 1 && p !== -1) { k = String(p); }
    if (k === "Enter") { k = "="; }
    else if (k === "Backspace") { k = "B"; }
    else if (k === "Escape" || k === "c" || k === "C") { k = "C"; }
    else if (k === ",") { k = "."; }
    if (k.length === 1 && "0123456789.+-*/=%CB".indexOf(k) !== -1) {
      e.preventDefault();
      handle(k);
    }
  });

  show();
})();

/* =========================================================
   ២) ប៊ូតុង Telegram - ដាក់សារទុកជាមុនក្នុងប្រអប់សរសេរ
   (អ្នកទស្សនាត្រូវចុច Send ម្តង ព្រោះ Telegram មិនអនុញ្ញាតឱ្យផ្ញើដោយស្វ័យប្រវត្តិ)
   ========================================================= */
(function () {
  var a = document.getElementById("kc-tg");
  if (!a) { return; }
  var user = a.getAttribute("data-user");
  var msg = a.getAttribute("data-message");
  if (user && msg) {
    a.href = "https://t.me/" + user + "?text=" + encodeURIComponent(msg);
  }
})();


/* =========================================================
   ៣) Motion details: entrance state and accessible interactions
   ========================================================= */
(function () {
  document.documentElement.classList.add("kc-motion-ready");
  var calc = document.getElementById("kc-calc");
  if (!calc || !window.matchMedia || window.matchMedia("(prefers-reduced-motion: reduce)").matches) { return; }

  // Subtle pointer parallax on desktop only; no effect on touch screens.
  if (window.matchMedia("(hover: hover) and (pointer: fine)").matches) {
    calc.addEventListener("pointermove", function (event) {
      var rect = calc.getBoundingClientRect();
      var x = (event.clientX - rect.left) / rect.width - .5;
      var y = (event.clientY - rect.top) / rect.height - .5;
      calc.style.transform = "perspective(900px) rotateX(" + (-y * 2.2) + "deg) rotateY(" + (x * 2.8) + "deg) translateY(-2px)";
    });
    calc.addEventListener("pointerleave", function () { calc.style.transform = ""; });
  }
})();
